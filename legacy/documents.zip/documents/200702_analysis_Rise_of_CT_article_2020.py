# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.18.1
#   kernelspec:
#     display_name: the-culture-of-international-relations
#     language: python
#     name: python3
# ---

# %% [markdown]
# # The Rise of the Cultural Treaty (graphs and analysis related to article draft, 2020)
#
# ### Introduction
# This page is meant as supplementary material to my article, "The Rise of the Cultural Treaty" (journal, date). Here I present the tools through which I, in collaboration with [Humlab at the University of Umeå](https://www.umu.se/en/humlab/), conducted the quantitative analysis (and prepared the data visualizations) presented in that article.
#
# Research on this project was funded by the Swedish Foundation for Humanities and Social Sciences (Riksbankens jubileumsfond).
#
# ### The data:
# Cultural treaties are the bi-lateral and multilateral agreements among states that promote and regulate cooperation and exchange in the fields of life generally called cultural or intellectual. In this article, I approach this source material through two data sets.
# 1. Metadata about all bilateral cultural agreements signed betweeen 1935 and 1972, as collected in the [electronic World Treaty Index (eWTI)](http://worldtreatyindex.com/) (Poast 2010).
#
# 2. The texts of a subset of these agreements. Our sample (or "corpus") includes the texts of all general cultural agreements deposited with the treaty services of the League of Nations (LTS) and the United Nations (UNTS) between 1935 and 1972.   
#
#
# #### Metadata
# A question I address in the article has to do with the definition of a "cultural treaty." Here, I largely follow the coding applied in the eWTI. This, I have confirmed, corresponds closely to categories developed by United Nations officials (see UNESCO 1962). But, as I discuss in the article, I have made several decisions to more sharply define the category. A detailed log of these choices is available as [a wiki on this project's GitHub page](https://github.com/humlab/the_culture_of_international_relations/wiki/eWTI-Notes:-Selection-Decisions-Log-2020). 
#
# What is relevant here is that I have devised two groupings: the first includes all bilateral agreements that were marked as "cultural" by their signatories, by international organizations and later by those responsible for the coding in the eWTI. This broad grouping I mark here at CULT7+. This group includes an important subset: agreements that UNESCO identifies as "general cultural agreements" (GCAs). These are bilateral agreements addressing relations in a broad range of fields (education, science, sports, as well as literature and the arts) all in one document. I have coded this subset as 7CULTGEN.    
#
# #### Text corpus
# We have assembled a corpus composed of the complete texts of all genearl cultural treaties (GCAs) deposited with the treaty services of the League of Nations (LTS) and the United Nations (UNTS) between 1935 and 1972 in English translation. These are signed by countries all over the world, although not to an even degree; that is, some countries account for many more such treaties than others. The League and later the UN published the treaties deposited there in book form until the 1990s. The paper volumes have been scanned in and are now accessible through [the UN's treaty collection website](https://treaties.un.org/Pages/Home.aspx?clang=_en) in pdf form (with OCR already applied to the English-language text).   
#
# ### The analysis: 
#
# This page presents two types of analysis:
# 1. quantitative analysis of metadata on cultural agreements from eWTI
# 2. quantitative text analysis of the treaty text corpus (LTS+UNTS, 1935-1972)
#
# I explore each of these in two sections, first addressing the data set as a whole and then dividing it up into several subsets, by state and geographical and/or politco-ideological region. So the overall structure below (as in the article) is as follows:
#
# 1. quantitative analysis of metadata on cultural agreements from eWTI
# 2. quantitative text analysis of our treaty text corpus (LTS+UNTS, 1935-1972)
# 3. quantitative analysis of metadata on selected states' cultural agreements from eWTI
# 4. quantitative text analysis of on selected states' agreements in our treaty text corpus (LTS+UNTS, 1935-1972)
#
# After some set-up sections, the analysis begins at "Part 1," below.

# %% [markdown]
# ### <span style='color:blue'>**Mandatory Prepare Step**</span>: Setup Notebook and Load and Process Treaty Master Index
# The following code cell to be executed once for each user session.

# %% code_folding=[]
# %load_ext autoreload
# %autoreload 2

import os
import warnings

warnings.filterwarnings('ignore')

import common.treaty_state as treaty_state

# %matplotlib inline

#wti_index = treaty_state.load_wti_index('../data', is_cultural_yesno_column='is_cultural_yesno_org')
#wti_index = treaty_state.load_wti_index('../data', is_cultural_yesno_column='is_cultural_yesno_plus')
wti_index = treaty_state.load_wti_index('../data', is_cultural_yesno_column='is_cultural_yesno_gen')

# %% [markdown]
# ### <span style='color:blue'>**Figure 1: Cultural Treaties, 1935-1972**</span>
#
# This graph shows the number of new bilateral "cultural" agreements signed by any two countries per year between 1935 and 1972. The set being counted includes all agreements included in the set 7CULT+ (see above).
#
# This group includes both bilateral general cultural agreements (which, according to a 1962 UNESCO publication, denoted "cultural conventions between two States or governments, dealing with all or several aspects of international relations in the field of education, science and culture") (UNESCO 1962, 65) as well as "specialized agreements" on "culture" (addressing such things as "cultural institutes; artistic exhibitions; protection of literary and artistic property,” regulating exchanges among the class of persons that includes "Artists (general); writers; musicians (composers, conductors, singers and instrumentalists); painters and sculptors; actors; film actors; dancers; artistes; architects; librarians; museum archivists; archaeologists". (UNESCO 1962, 18)).

# %%
import topic_analysis_gui

args = {
    'chart_per_category': False,                # Overlay charts
    'chart_type_name': 'plot_stacked_bar',      # Kind of charts (see config.CHART_TYPES, attribute name for valid keys)
    'include_other_category': False,            # Add 'ALL' or 'ALL_OTHER' category
    'normalize_values': False,                  # Normalize each values in each category to 100%
    'parties': ('ALL',),                        # Parties to include
    'period_group_index': 4,                    # Period group item index in config.DEFAULT_PERIOD_GROUPS (first item has index 0)
    'plot_style': 'seaborn-v0_8-pastel',             # Matplotlib plot style (see config.yml for valid values)
    'recode_is_cultural': True,                 # Flag: recode is_cultural='Yes' to topic '7CORR'
    'target_quantity': 'topic',                 # Target entity type: 'topic' or 'party'
    'topic_group_name': '7CORR',                # Topic group name (see config.DEFAULT_TOPIC_GROUPS)
    'wti_index': wti_index,                     # WTI index to use, assigned in SETUP CELL above
    #'treaty_sources': None # ['LTS', 'UNTS', 'UNXX']
    'treaty_sources': ['LTS', 'UNTS', 'UNXX']
}
topic_analysis_gui.display_topic_quantity_groups(**args)

# %% [markdown]
# ### <span style='color:blue'>**Figure 2: Cultural Agreements (more broadly defined), 1935-1972**</span>
# This chart shows the number of new bilateral agreements signed per year on all topics that the WTI, following UNESCO, defined as "cultural" (that is, under the heading 7, "Culture"). _MAYBE just cut this._ 
#
# This chart shows that the use over time of all the treaty categories included under the heading 7Culture. One feature stands out in particular: that treaties in the category 7CULT predominate over the other types. 
#

# %%
import topic_analysis_gui

args = {
    'chart_per_category': False,                # Overlay charts
    'chart_type_name': 'plot_stacked_bar',      # Kind of charts (see config.CHART_TYPES, attribute name for valid keys)
    'include_other_category': False,              # Add 'ALL' or 'ALL_OTHER' category
    'normalize_values': False,                  # Normalize each values in each category to 100%
    'parties': ('ALL',),                     # Parties to include
    'period_group_index': 4,                    # Period group item index in config.DEFAULT_PERIOD_GROUPS (first item has index 0)
    'plot_style': 'seaborn-v0_8-pastel',             # Matplotlib plot style (see config.yml for valid values)
    'recode_is_cultural': True,                 # Flag: recode is_cultural='Yes' to topic '7CORR'
    'target_quantity': 'topic',                 # Target entity type: 'topic' or 'party'
    'topic_group_name': '7CULTURE',             # Topic group name (see config.DEFAULT_TOPIC_GROUPS)
    'wti_index': wti_index,                      # WTI index to use, assigned in SETUP CELL above

    # 2020-07-02 New filter (None disables filter i.e. previous behaviour)
    'treaty_sources': None
    # 'treaty_sources': ['LTS', 'UNTS', 'UNXX']
}
topic_analysis_gui.display_topic_quantity_groups(**args)

# %% [markdown]
# ### <span style='color:blue'>**Figure 3: Cultural Treaties as a percentage of all treaty-making, per year, 1935-1972**</span>
#
# Figure 3 shows us 7CORR compared to all other treaties, by year, 1935-1972, by percentage. This shows that cultural treaties never accounted for great portion of total treaty-making; but also that the increases in cultural treaty-making in the late 1950s and mid-1960s cannot simply be attributed to the growth in treaty-making over all. Cultural treaty-making represented on average 2.7% of the total number of treaties signed per year from 1945 to 1955, but 5.7% of all new bilateral agreements signed per year in the following decade (1956 to 1965). In 1966 they represented no less than 7.6%.

# %%
import topic_analysis_gui

args = {
    'chart_per_category': False,               # Overlay charts
    'chart_type_name': 'plot_stacked_bar',     # Kind of charts (see config.CHART_TYPES, attribute name for valid keys)
    'include_other_category': True,              # Add 'ALL' or 'ALL_OTHER' category
    'normalize_values': True,                  # Normalize each values in each category to 100%
    'parties': ('ALL',),                       # Parties to include
    'period_group_index': 4,                   # Period group item index in config.DEFAULT_PERIOD_GROUPS (first item has index 0)
    'plot_style': 'seaborn-v0_8-pastel',            # Matplotlib plot style (see config.yml for valid values)
    'recode_is_cultural': True,                # Flag: recode is_cultural='Yes' to topic '7CORR'
    'target_quantity': 'topic',                # Target entity type: 'topic' or 'party'
    'topic_group_name': '7CORR',               # Topic group name (see config.DEFAULT_TOPIC_GROUPS)
    'wti_index': wti_index,                      # WTI index to use, assigned in SETUP CELL above,

    # 2020-07-02 New filter (None disables filter i.e. previous behaviour)
    'treaty_sources': None
    # 'treaty_sources': ['LTS', 'UNTS', 'UNXX']
}
topic_analysis_gui.display_topic_quantity_groups(**args)

# %% [markdown]
# ### <span style='color:blue'>**Cultural Treaties as a percentage of all treaty-making, per year, 1935-1972 (table)**</span> 
#
# Below, we see the percentage data in table format. 

# %%
import os
import pandas as pd
from IPython.display import display, HTML
import common.config as config
import common.treaty_state as treaty_repository
import analysis_data

data = analysis_data.QuantityByTopic.get_treaty_topic_quantity_stat(
    wti_index                 = wti_index,
    period_group              = config.DEFAULT_PERIOD_GROUPS[4],
    topic_category            = config.TOPIC_GROUP_MAPS['7CORR'],
    party_group               = { 'label': 'ALL', 'parties': None },
    recode_is_cultural        = True,
    include_other_category      = True,
    target_quantity           = 'topic',
    # 20200702 New filter
    treaty_sources            = None # or ['LTS', 'UNTS', 'UNXX']
)

pivot = pd.pivot_table(data, index=['Period'], values=["Count"], columns=['Category'], fill_value=0)
pivot.columns = [ x[-1] for x in pivot.columns ]

normalized_pivot = pivot.div(0.01 * pivot.sum(1), axis=0)

#display(pivot)
display(normalized_pivot)


# %% [markdown]
# ### <span style='color:blue'>**Figure 4: Cultural Treaties vs recognition agreements**</span>
#
# Figure 4 compares the number of new cultural treaties (7CULT+) to recognition agreements, typically signed with new states.
#
# The cultural treaty existed already after World War II, but diplomats chose only rarely to use it in the first postwar decade, although there were many new states and, one might think, a lot of relationships in need of being reestablished. Something seems to have happened beginning in 1957 -- something beyond the mere apperance of new states, that is -- that made the cultural treaty seem newly attractive and relevant to diplomats.

# %%
import topic_analysis_gui

args = {
    'chart_per_category': False,                # Overlay charts
    'chart_type_name': 'plot_line',      # Kind of charts (see config.CHART_TYPES, attribute name for valid keys)
    'include_other_category': False,              # Add 'ALL' or 'ALL_OTHER' category
    'normalize_values': False,                  # Normalize each values in each category to 100%
    'parties': ('ALL',),                     # Parties to include
    'period_group_index': 4,                    # Period group item index in config.DEFAULT_PERIOD_GROUPS (first item has index 0)
    'plot_style': 'seaborn-v0_8-pastel',             # Matplotlib plot style (see config.yml for valid values)
    'recode_is_cultural': True,                 # Flag: recode is_cultural='Yes' to topic '7CORR'
    'target_quantity': 'topic',                 # Target entity type: 'topic' or 'party'
    'topic_group_name': '7CORR + 1RECOG',             # Topic group name (see config.DEFAULT_TOPIC_GROUPS)
    'wti_index': wti_index,                      # WTI index to use, assigned in SETUP CELL above
     # 20200702 New filter
    'treaty_sources': None # or ['LTS', 'UNTS', 'UNXX']
}
topic_analysis_gui.display_topic_quantity_groups(**args)

# %% [markdown]
# ### Testing: which of the category 1 treaty types accounts for the largest share of 1Diplomacy?
#
# This shows that: 
# * treaties of amity were big in the 1930s and quite common 1950-60
# * treaties of reparation were used a lot after WWII but do not account for a large proportion of these otherwise
# * treaties of recognition accounts for the big spikes: 1945, 1953, 1956, 1960, 1962, 1972.
#
# Oddly, these treaties, too, seem disproportionately often to be signed by France, USSR, or (in 1972) East Germany. Didn't the US (for example) recognize newly sovereign countries, too? But without signing a treaty about it, perhaps? 

# %%
import topic_analysis_gui

args = {
    'chart_per_category': False,                # Overlay charts
    'chart_type_name': 'plot_line',      # Kind of charts (see config.CHART_TYPES, attribute name for valid keys)
    'include_other_category': False,              # Add 'ALL' or 'ALL_OTHER' category
    'normalize_values': False,                  # Normalize each values in each category to 100%
    'parties': ('ALL',),                     # Parties to include
    'period_group_index': 4,                    # Period group item index in config.DEFAULT_PERIOD_GROUPS (first item has index 0)
    'plot_style': 'seaborn-v0_8-pastel',             # Matplotlib plot style (see config.yml for valid values)
    'recode_is_cultural': False,                 # Flag: recode is_cultural='Yes' to topic '7CORR'
    'target_quantity': 'topic',                 # Target entity type: 'topic' or 'party'
    'topic_group_name': '1DIPLOMACY',             # Topic group name (see config.DEFAULT_TOPIC_GROUPS)
    'wti_index': wti_index,                      # WTI index to use, assigned in SETUP CELL above
     # 20200702 New filter
    'treaty_sources': None # or ['LTS', 'UNTS', 'UNXX']
}
topic_analysis_gui.display_topic_quantity_groups(**args)

# %% [markdown]
# ### <span style='color:blue'>**Part II: Text Analysis**</span>
# ### Table 1
#
# Table 1 shows the most frequent nouns in the text corpus LTS+UNTS GCAs, 1935-1972. Here we present the code showing how we produced the table (of csv values) of noun frequencies. There is no graph (nor, obviously, this entire table) in the article text. Below is one set-up code window, followed by the tool itself.

# %%
import sys
import ipywidgets as widgets

import matplotlib.pyplot as plt
from common import utility, treaty_utility, treaty_state, config, setup_config
from IPython.display import display
from loguru import logger

await setup_config()

from common.gui.load_wti_index_gui import load_wti_index_with_gui, current_wti_index
from common.corpus.textacy_corpus_utility import CorpusContainer
from common.gui import textacy_corpus_gui

load_wti_index_with_gui(data_folder=config.DATA_FOLDER)

# %matplotlib inline

current_corpus_container = lambda: CorpusContainer.container()
current_corpus = lambda: CorpusContainer.corpus()

try:
    container = current_corpus_container()
    textacy_corpus_gui.display_corpus_load_gui(config.DATA_FOLDER, current_wti_index(), container)
except Exception as ex:
    logger.error(ex)


# %%
from common.gui import word_frequencies_gui as wf_gui
try:
    wf_gui.word_frequency_gui(current_wti_index(), current_corpus())
except Exception as ex:
    print(ex)

# %% [markdown]
# ### <span style='color:blue'>**Figure 5: Word-in-document frequencies of selected nouns**</span>
#
# Here we present the tool with which we calculate if a (lemmatized) word appeared or not in the cultural agreements signed in a given year. Using this we produced data (as csv files), that can be opened and manipulated in excel. Figure 5 is based on this data.

# %%

import pandas as pd

def compute_doc_frequencies(corpus, token_to_find, normalize='lemma'):
    f =  { 'lemma': lambda x: x.lemma_, 'lower': lambda x: x.lower_, 'orth': lambda x: x.orth_ }[normalize]
    token_to_find = token_to_find.lower() if normalize != 'orth' else token_to_find
    data = {}
    for doc in corpus:
        signed_year = doc._.meta['signed_year']
        if signed_year not in data:
            data[signed_year] = { 'signed_year': signed_year,  'match_count': 0, 'total_count': 0}
        data[signed_year]['total_count'] += 1
        if token_to_find in [ f(x) for x in doc ]:
            data[signed_year]['match_count'] += 1
    df = pd.DataFrame(list(data.values())).set_index('signed_year')
    df['doc_frequency'] = (df.match_count / df.total_count) * 100
    df = df[['total_count', 'match_count', 'doc_frequency']]
    return df

def word_doc_frequencies_gui(corpus):
    normalize_options   = { 'Text':  'orth', 'Lemma': 'lemma', 'Lower': 'lower' }
    
    gui = types.SimpleNamespace(
        normalize=widgets.Dropdown(description='Normalize', options=normalize_options, value='lemma', layout=widgets.Layout(width='200px')),
        compute=widgets.Button(description='Compute', button_style='Success', layout=widgets.Layout(width='120px')),
        token=widgets.Text(description='Word'),
        output=widgets.Output(layout={'border': '1px solid black'})
    )
    
    boxes = widgets.VBox([
        widgets.HBox([
            gui.normalize,
            gui.token,
            gui.compute
        ]),
        gui.output
    ])
    
    display(boxes)
    
    def compute_callback_handler(*_args):
        gui.output.clear_output()
        with gui.output:
            try:
                gui.compute.disabled = True
                df_counts = compute_doc_frequencies(
                    corpus=corpus,
                    token_to_find=gui.token.value,
                    normalize=gui.normalize.value
                )
                display(df_counts)
            except Exception as ex:
                logger.error(ex)
                raise
            finally:
                gui.compute.disabled = False

    gui.compute.on_click(compute_callback_handler)

try:
    word_doc_frequencies_gui(current_corpus())
except Exception as ex:
    logger.error(ex)

# %% [markdown]
# ### <span style='color:blue'>**Part III: Quantative analysis of WTI, specific countries and regions**</span>
#

# %% [markdown]
# ### <span style='color:blue'>**Figure 9: Which Countries? Top 3 signatories to Cultural Treaties by five-year period**</span>
#
# Which states entered into cultural treaties most often? This chart shows the top three countries that signed the most cultural treaties by period, where the periods are (_EDIT FROM HERE_)  ... 1919-1944, 1945-1955, 1956-1966, and 1967-1972. Rather than assuming which are the great powers here, this graph allows us to see which countries in fact took the lead in the use of this particular technology of international relations. We find that a particular set of countries were leading actors in the use of the cultural treaty. 
# * France was among the top three in every period.
# * During the interwar period and during World War II, Latin American countries were among the most frequent signatories of such agreements. The top three postions of Brazil and Bolivia here are largely accounted for by those states' busy treaty-making, almost exclusively with fellow Latin American states, during the war.
# * Cultural treaty-making in the decade following the war was led by three Southern European states: France, Italy, and Spain.
# * The period of "take off" in cultural treaty-making was dominated by new powers: France was joined by the Soviet Union and Egypt.
# * The Soviet Union and France maintained a leading role in the late 1960s and early 1970s, joined now by another Eastern bloc state, the German Democratic Republic.
#
# This raises questions about why these particular nations were so active. A large volume of treaty-making may normally be a sign of a state's great power status. But a large volume of cultural treaty-making seems to reflect something else. Let us compare the activity in this sector of the post-war era's other great powers.
#
# QUESTION:
# Can we do running 5-year averages, or compare to alternative time blocs (decades 1940-50, 51-60, 61-72)? 
#

# %%
import party_analysis_gui
args = {
    'parties': (),            # Parties to include
    'treaty_filter': 'is_cultural',             # Treaty filter (see config.TREATY_FILTER_OPTIONS)
    'party_name': 'party_name',                 # Party name to use (see config.PARTY_NAME_OPTIONS)
    'top_n_parties': 3,                         # Used? Filter on top parties per category
    'extra_category': '',                       # Add 'ALL' or 'ALL_OTHER' category
    'plot_style': 'seaborn-v0_8-pastel',             # Matplotlib plot style (see config.yml for valid values)
    'wti_index': wti_index,                     # WTI index to use, assigned in SETUP CELL above
    'period_group_index': 2,                    # Period item index in config.DEFAULT_PERIOD_GROUPS (first item has index 0)
    'normalize_values': False,                  # Normalize each values in each category to 100%
    'overlay': True,                            # Used? Display one chart per category
    'chart_type_name': 'plot_stacked_bar',      # Kind of charts (see config.CHART_TYPES, attribute name for valid keys)
    'year_limit': (1919, 1972)                  # Signed year filter
}

party_analysis_gui.display_quantity_by_party(**args)

# %% [markdown]
# ### <span style='color:blue'>**Which Countries? Use of cultural treaties by the P5 (Chart 7)**</span>
#
# This chart shows the number of new cultural agreements signed by the permanent members of the United Nations Security Council, the so-called P5. This shows that two countries on the P5 accounted for the overwhelming majority of cultural agreements signed: France and the Soviet Union.
# This graph shows, too, part of what happened in 1956 to account for the burst in new cultural agreements: the USSR discovered the genre. Likewise, the burst of 1966 seems to be acccounted for largely by France.
#
# The Anglo-American bloc made quite modest use of the cultural treaty. The Soviets and the French made extensive use. Accounting for the first observation does not seem terribly difficult: the United States and British governments were evidently skeptical about the value of such agreements and chose to enter into only a few. But what is the common element that accounts for the Soviet and French states' parallel investment in this diplomatic tool?
#
# CHECK: What can we say about China here? Is this data on ROC or PRC? Compare and do sanity check of "China" vs "Taiwan" in WTI excel file, confirming source.

# %%
import topic_analysis_gui

args = {
    'chart_per_category': False,                # Overlay charts
    'chart_type_name': 'plot_line',      # Kind of charts (see config.CHART_TYPES, attribute name for valid keys)
    'include_other_category': False,              # Add 'ALL' or 'ALL_OTHER' category
    'normalize_values': False,                  # Normalize each values in each category to 100%
    'parties': ('CHINA', 'FRANCE', 'USSR', 'UK', 'USA',),                     # Parties to include
    'period_group_index': 3,                    # Period group item index in config.DEFAULT_PERIOD_GROUPS (first item has index 0)
    'plot_style': 'seaborn-v0_8-pastel',             # Matplotlib plot style (see config.yml for valid values)
    'recode_is_cultural': True,                 # Flag: recode is_cultural='Yes' to topic '7CORR'
    'target_quantity': 'party',                 # Target entity type: 'topic' or 'party'
    'topic_group_name': '7CORR',             # Topic group name (see config.DEFAULT_TOPIC_GROUPS)
    'wti_index': wti_index                      # WTI index to use, assigned in SETUP CELL above
}
topic_analysis_gui.display_topic_quantity_groups(**args)

# %% [markdown]
# ### <span style='color:blue'>**Cultural Treaty Networks: The Soviets (Figure 8)**</span>
#
# Having determined that France and the Soviet Union were the leading users of the cultural treaty, we can use this data to further explore _how_ they used such treaties, by visualizing the WTI data as networks. 
# In the case of the USSR, the year to focus on is obviously 1956. What motivated the decision to suddenly sign thirteen cultural agreements in one year, having never signed a single one prior to this point? The Soviets of course had no lack of experience in pursuing cultural diplomacy. But some set of factors led the regime to turn to this diplomatic tool at this point. A first step to exploring this question is, naturally, to see with which countries the Soviets entered into cultural agreements.
#
# In the image below we see the Soviet Union's cultural treaties signed in 1956 visualized as a network. 1956 was the year that the regime decided for the first time to invest in the genre. This investment was evidently aimed almost exclusively at consolidating ties with countries that were firmly in the socialist orbit: the central and eastern European communist dictatorships already under Soviet control and several socialist states in Asia. And, for some reason, Norway.
#
# Observing that Syria was part of this group sends us looking for information about this. (The USSR apparently signed a broader pact with Syria that year, but this is not in WTI.) The closeness of the two regimes in 1956 triggered a major international crisis. *More on this here* 
#
# A final note: this little excursus on Syrian-Soviet relations is, if I may say so, evidence of this digital method working as I hoped it would: looking with digital tools at a global data set allows us to identify items of interest--particular developments of relevance to the broader history of cultural diplomacy--that would surely have escaped my notice otherwise.    

# %% code_folding=[]
import common.utility as utility
import network_analysis_gui
from bokeh.plotting import output_notebook

output_notebook()
    
args = {
    'C': 1,
    'K': 0.1,
    'height': 700,
    'layout_algorithm': 'nx_spring_layout',
    'node_partition': None,
    'node_size': None,
    'node_size_range': (20, 49),
    'output': 'network',
    'p1': 1.1,
    'palette_name': None,
    'parties': ('FRANCE', 'USSR'),
    'party_name': 'party_name',
    'period_group_index': 3,
    'plot_data': None,
    'recode_is_cultural': True,
    'topic_group': {'7CORR': '7CORR'},
    'treaty_filter': 'is_cultural',
    'year_limit': (1955, 1956),
    'width': 900,
    'wti_index': wti_index
}

network_analysis_gui.display_party_network(**args)

# %% [markdown]
# ### <span style='color:blue'>**Cultural Treaty Networks: France, part 1 (Figure 9)**</span>
#
# Let us turn now to France. The first graph below shows the network created by France's cultural treaties from 1945 to 1958. 
#
# 1958 was a year when France signed no cultural treaties, which can serve as a cut off point before the new phase of treaty-making linked to decolonization (which is the subject of the next visualization). 
#
# #### QUESTION: cannot get this to show me France's treaty network; it says "no data" but that's not true!

# %%
import common.utility as utility
import network_analysis_gui
from bokeh.plotting import output_notebook

output_notebook()
    
args = {
    'C': 1,
    'K': 0.1,
    'height': 700,
    'layout_algorithm': 'nx_spring_layout',
    'node_partition': None,
    'node_size': None,
    'node_size_range': (20, 49),
    'output': 'network',
    'p1': 1.1,
    'palette_name': None,
    'parties': ('USSR', 'France'),
    'party_name': 'party_name',
    'period_group_index': 3,
    'plot_data': None,
    'recode_is_cultural': True,
    'topic_group': {'7CORR': '7CORR'},
    'treaty_filter': 'is_cultural',
    'year_limit': (1945, 1958),
    'width': 900,
    'wti_index': wti_index
}

network_analysis_gui.display_party_network(**args)

# %% [markdown]
# ### <span style='color:blue'>**Cultural Treaty Networks: France, part 2 (Figure 10)**</span>
#
# This next graph shows the network created by France's cultural treaties from 1960 to 1970, at the height of African decolonization.

# %%
import common.utility as utility
import network_analysis_gui
from bokeh.plotting import output_notebook

output_notebook()
    
args = {
    'C': 1,
    'K': 0.1,
    'height': 700,
    'layout_algorithm': 'nx_spring_layout',
    'node_partition': None,
    'node_size': None,
    'node_size_range': (20, 49),
    'output': 'network',
    'p1': 1.1,
    'palette_name': None,
    'parties': ('France'),
    'party_name': 'party_name',
    'period_group_index': 3,
    'plot_data': None,
    'recode_is_cultural': True,
    'topic_group': {'7CORR': '7CORR'},
    'treaty_filter': 'is_cultural',
    'year_limit': (1960, 1970),
    'width': 900,
    'wti_index': wti_index
}

network_analysis_gui.display_party_network(**args)

# %% [markdown]
# ### <span style='color:blue'>**Comparing Networks of different Treaty Types: (Figure 11)**</span>
#
# One might suspect that cultural treaties served as little more than window dressing for bilateral agreements that were really about something else. One way to test that theory with this data is to compare a given country's treaty networks by different treaty types. Below are visualizations of France's economic agreements in the period 1960-1970. How does this compare to the network created by France's cultural treaties signed in the same period?  
#
# #### Getting "no data" here, too...not sure why.

# %% [markdown]
# import common.utility as utility
# import network_analysis_gui
# from bokeh.plotting import output_notebook
#
# output_notebook()
#     
# args = {
#     'C': 1,
#     'K': 0.1,
#     'height': 700,
#     'layout_algorithm': 'nx_spring_layout',
#     'node_partition': None,
#     'node_size': None,
#     'node_size_range': (20, 49),
#     'output': 'network',
#     'p1': 1.1,
#     'palette_name': None,
#     'parties': ('France'),
#     'party_name': 'party_name',
#     'period_group_index': 3,
#     'plot_data': None,
#     'recode_is_cultural': False,
#     'topic_group': {'ECONOMIC': ['3CLAIM', '3COMMO', '3CUSTO', '3ECON', '3INDUS', '3INVES', '3MOSTF', '3PATEN', '3PAYMT', '3PROD', '3TAXAT', '3TECH', '3TOUR', '3TRADE', '3TRAPA']},
#     'treaty_filter': 'is_cultural',
#     'year_limit': (1945, 1958),
#     'width': 900,
#     'wti_index': wti_index
# }
#
# network_analysis_gui.display_party_network(**args)

# %% [markdown]
# ### <span style='color:blue'>**Conclusion**</span>
#
# Much remains to be done with cultural treaties, using these methods, and using other (more traditional) approaches. But the above analysis of the treaty metadata allows us to draw a few provisional conclusions.
#
#
#
#
#
#

# %% [markdown]
# IGNORE BELOW HERE, get rid of eventually...
#
#
# ### Chart: Treaty Quantities by Selected Parties 
# This chart displays the number of treaties per time period for each party or group of parties. The time period can be year or one of a predefined set of time period divisions. The default time period division is 1919-1944, 1945-1955, 1956-1966, and 1967-1972, the alternative division has 1940-1944 as an additional period. The third division is a single period between 1945 and 1972 (inclusive)
#
# Several parties can be selected using CTRL + click on left mouse button. Shift-Up/Down can also be used to select consecutive parties. Some predefined party sets exist in the "Preset" dropdown, and, when selected, the corresponding parties is selected in the "Parties" widget. Use the "Top #n" slider to display parties with most treaties for each period. Note that a value greater than 0 will disable the "Parties" widget since these to selections are mutually exclusive. Set slider back to 0 to enable the "Parties" widget.
#
# The treaty count is based on the following rules:
# - Treaties outside of selected division are discarded
# - When "Is Cultural" is selected than the only treaties included are those having "is cultural" flag in WTI index set to "Yes" 
# - When "Topic is 7CULT" is selected than all treaties having topic equal to 7CULT are included using original topic value according to WTI i.e. no recoding!
# - Candidate for removal: When "No filter" is selected then no topic filter is applied
#
# The topic filter also restricts the extra category count added when "Other category" or "All category" are selected. When "Other" is selected, than the "complement" count of the sum of all countries not included is added as a category, and the "All" category adds the count of all treaties. Note again, that both these counts are restricted by time period (no treaty outside period), and selected topic filter.
#
# Also note that when several countries are selected, than the count for a given country is the count of all treaties that country signed for each time period (filtered by topic selection). Each of the treaties that are signed *between* two of the selected parties will hence add +1 for each of the two parties.
#

# %% [markdown]
# Example on how to create a chart, in code, using a pre-defined parameter setup:
# <span style='font-size: 8pt'>
# ```python
# args = {
#     'overlay': True,
#     'top_n_parties': 0,
#     'plot_style': 'seaborn-pastel',
#     'chart_type_name': 'plot_stacked_bar',
#     'normalize_values': False,
#     'extra_category': '',
#     'treaty_filter': 'is_cultural',
#     'year_limit': (1945, 1972),
#     'parties': ('FRANCE', 'SWEDEN'),
#     'period_group_index': 3,
#     'party_name': 'party_name'
# }
# display_quantity_by_party(**args)
# ```
# </span>
#

# %% code_folding=[1]
import party_analysis_gui
args = {
    'parties': ('FINLAN', 'FRANCE'),            # Parties to include
    'treaty_filter': 'is_cultural',             # Treaty filter (see config.TREATY_FILTER_OPTIONS)
    'party_name': 'party_name',                 # Party name to use (see config.PARTY_NAME_OPTIONS)
    'top_n_parties': 0,                         # Used? Filter on top parties per category
    'extra_category': '',                       # Add 'ALL' or 'ALL_OTHER' category
    'plot_style': 'seaborn-v0_8-pastel',             # Matplotlib plot style (see config.yml for valid values)
    'wti_index': wti_index,                     # WTI index to use, assigned in SETUP CELL above
    'period_group_index': 3,                    # Period item index in config.DEFAULT_PERIOD_GROUPS (first item has index 0)
    'normalize_values': False,                  # Normalize each values in each category to 100%
    'overlay': True,                            # Used? Display one chart per category
    'chart_type_name': 'plot_stacked_bar',      # Kind of charts (see config.CHART_TYPES, attribute name for valid keys)
    'year_limit': (1945, 1972)                  # Signed year filter
}

party_analysis_gui.display_quantity_by_party(**args)

# %% [markdown]
# ###  Chart: Treaty Quantities by Selected Topics [CHANGE!]
# This chart displays the number of treaties per selected category and time period. The category can be wither topic or party. Only treaties signed by one of the selected parties are included in the count (unless either of ALL OTHER or ALL is selected, see below).
#
# See previous chart for a description of "period" and "parties" options (the same rules apply in this chart).
#
# Topics **not** specified in the selected "Category" are as default **excluded** from the counts. If the "Add OTHER topics" toggle is set then a new "OTHER" category is added as a summed up count for topics outside the selected topic category. 
#
# Note that, as default when the "Recode 7CORR" is set, all treaties marked as "is_cultural" = "Yes" in the WTI index are assigned a new topic code "7CORR". The remaining treaties ´having topic 7CULT are not recoded (will keep this code).
#
# When the "Chart per Qty" toggle is set, then a seperate chart is created for each category (of selected Quantity). Please not that this might take some time if, if the category selection contains many items. Extra charts will also be created for **excluded** category items (i.e. parties not selected or topics not included in topic category) if either of the "ALL OTHER" or "ALL" party items are selected. In both cases the category filter is applies as for any other chart.
#
# The topic categories are defined in file **.\common\config.py** in the "category_group_settings" and is common to all notebooks. A topic category has the following the structure
# ```python
# category_group_settings = {
#     'category-group-name': {
#         'category-item-1': [list-of-topic-codes-in-category-1],
#         'category-item-2': [list-of-topic-codes-in-category-2],
#         ...
#         'category-item-n': [list-of-topic-codes-in-category-n]
#     },
# ```
# The **category-group-name**s will be visible in the "Category" dropdown list, and it is hence important for these names to be unique. It can be an arbitrary name. The **category-item**s is the name that will be visible on the chart legend as label for associated list of topic-codes. The **list-of-topic-codes**, finally, must be a list of valid topic codes in the WTI-index (+ 7CORR). Note that these lists within the same category-group should be mutually exclusive i.e. the same code should not be added to more than one group (will give an unpredicted result). Also note that correct braces **must** be used, and strings **must** be surrounded by "'", and all topic codes must also be in uppercase. Follow the same syntax as in the existing specifications. 

# %%
import topic_analysis_gui

args = {
    'chart_per_category': False,                # Overlay charts
    'chart_type_name': 'plot_stacked_bar',      # Kind of charts (see config.CHART_TYPES, attribute name for valid keys)
    'include_other_category': False,              # Add 'ALL' or 'ALL_OTHER' category
    'normalize_values': False,                  # Normalize each values in each category to 100%
    'parties': ('FRANCE',),                     # Parties to include
    'period_group_index': 3,                    # Period group item index in config.DEFAULT_PERIOD_GROUPS (first item has index 0)
    'plot_style': 'seaborn-v0_8-pastel',             # Matplotlib plot style (see config.yml for valid values)
    'recode_is_cultural': True,                 # Flag: recode is_cultural='Yes' to topic '7CORR'
    'target_quantity': 'topic',                 # Target entity type: 'topic' or 'party'
    'topic_group_name': '7CULTURE',             # Topic group name (see config.DEFAULT_TOPIC_GROUPS)
    'wti_index': wti_index                      # WTI index to use, assigned in SETUP CELL above
}
topic_analysis_gui.display_topic_quantity_groups(**args)

# %% [markdown]
# Describe Network visualizations...

# %%
import common.utility as utility
import network_analysis_gui
from bokeh.plotting import output_notebook

output_notebook()
    
args = {
    'C': 1,
    'K': 0.1,
    'height': 700,
    'layout_algorithm': 'nx_spring_layout',
    'node_partition': None,
    'node_size': None,
    'node_size_range': (20, 49),
    'output': 'network',
    'p1': 1.1,
    'palette_name': None,
    'parties': ('FRANCE', 'ITALY', 'UK', 'GERM'),
    'party_name': 'party_name',
    'period_group_index': 3,
    'plot_data': None,
    'recode_is_cultural': True,
    'topic_group': {'7CORR': '7CORR'},
    'treaty_filter': 'is_cultural',
    'year_limit': (1945, 1950),
    'width': 900,
    'wti_index': wti_index
}

network_analysis_gui.display_party_network(**args)


# %%
